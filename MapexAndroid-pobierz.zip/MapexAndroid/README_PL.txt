MAPEX – projekt startowy Android (wersja 0.1.0)

To jest natywny projekt Android Studio, a nie gotowy plik APK.
Zawiera ekran startowy i makiety zakładek Mapa, Pociągi, Alerty i Ustawienia.
Nie ma jeszcze prawdziwego silnika map, GPS, routingu, aktualnych danych PKP ani wysyłania zgłoszeń.

Jak zbudować APK:
1. Zainstaluj Android Studio na komputerze.
2. Otwórz w Android Studio folder MapexAndroid.
3. Pozwól Android Studio pobrać wymagane komponenty SDK/Gradle.
4. Wybierz Build > Build Bundle(s) / APK(s) > Build APK(s).
5. APK znajdziesz w app/build/outputs/apk/debug/app-debug.apk.

Wersja debug jest do testów. Oficjalna publikacja wymaga osobnego podpisania wersji release.
Doc: https://developer.android.com/build/building-cmdline
