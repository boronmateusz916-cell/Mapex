package pl.mapex.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    int bg = Color.rgb(7, 15, 30), panel = Color.rgb(16, 29, 49), blue = Color.rgb(0, 145, 255), white = Color.WHITE, muted = Color.rgb(164, 181, 205);
    LinearLayout root, content;
    TextView heading(String s, int size) { TextView t = new TextView(this); t.setText(s); t.setTextColor(white); t.setTextSize(size); t.setTypeface(null, Typeface.BOLD); return t; }
    TextView body(String s) { TextView t = new TextView(this); t.setText(s); t.setTextColor(muted); t.setTextSize(14); return t; }
    GradientDrawableCompat shape(int color) { return new GradientDrawableCompat(color); }
    class GradientDrawableCompat extends android.graphics.drawable.GradientDrawable { GradientDrawableCompat(int c){setColor(c);setCornerRadius(22);setStroke(1, Color.rgb(39,67,100));} }
    void card(String title, String desc) { LinearLayout c = new LinearLayout(this); c.setOrientation(1); c.setPadding(18,16,18,16); c.setBackground(shape(panel)); TextView a=heading(title,18); TextView b=body(desc); b.setPadding(0,7,0,0); c.addView(a); c.addView(b); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.setMargins(0,0,0,12); content.addView(c,p); }
    void show(String tab) {
        content.removeAllViews();
        if(tab.equals("Mapa")) {
            content.addView(heading("Gdzie jedziemy?",25));
            EditText from=new EditText(this); from.setSingleLine(true); from.setHint("Punkt startowy"); from.setTextColor(white); from.setHintTextColor(muted); from.setPadding(16,12,16,12); from.setBackground(shape(panel)); content.addView(from);
            EditText to=new EditText(this); to.setSingleLine(true); to.setHint("Wpisz cel podróży"); to.setTextColor(white); to.setHintTextColor(muted); to.setPadding(16,12,16,12); to.setBackground(shape(panel)); LinearLayout.LayoutParams m=new LinearLayout.LayoutParams(-1,-2); m.setMargins(0,10,0,15); content.addView(to,m);
            card("Wybierz środek transportu", "🚗 Samochód     🚴 Rower     🚶 Pieszo");
            card("Mapa Mapex", "Tutaj pojawi się mapa i prowadzenie po rzeczywistych drogach, chodnikach i ścieżkach rowerowych. Moduł map i tras wymaga jeszcze podłączenia.");
            card("Trasy", "Trasa najszybsza • Alternatywna • Zapasowa");
        } else if(tab.equals("Pociągi")) {
            content.addView(heading("Odjazdy pociągów",25));
            EditText station=new EditText(this); station.setSingleLine(true); station.setHint("Wpisz stację, np. Ostrów Wielkopolski"); station.setTextColor(white); station.setHintTextColor(muted); station.setPadding(16,12,16,12); station.setBackground(shape(panel)); content.addView(station);
            card("Tablica odjazdów", "Godzina • kierunek • przewoźnik • peron • tor • opóźnienie");
            card("Dane kolejowe", "Po podłączeniu oficjalnych danych pokażemy aktualny rozkład. Peron i tor będą oznaczone jako niepotwierdzone, jeśli brak wiarygodnej informacji.");
        } else if(tab.equals("Alerty")) {
            content.addView(heading("Alerty drogowe",25));
            card("Zgłoszenia społeczności", "Fotoradary • patrole • roboty drogowe • wypadki • korki • zwierzęta • przeszkody");
            card("Bezpieczeństwo", "Zgłoszenia i potwierdzenia użytkowników zostaną dodane w kolejnej wersji.");
        } else {
            content.addView(heading("Ustawienia Mapex",25));
            card("Wygląd mapy", "Standardowa • Satelitarna • Własny styl");
            card("Nawigacja", "Widok 2D / 3D • głos • głośność • automatyczne przeliczanie trasy");
            card("Mapy offline", "Pobieranie wybranych obszarów zostanie dodane po wdrożeniu silnika map.");
        }
    }
    @Override public void onCreate(Bundle b) { super.onCreate(b); getWindow().setStatusBarColor(bg); getWindow().setNavigationBarColor(bg);
        root=new LinearLayout(this); root.setOrientation(1); root.setPadding(18,18,18,8); root.setBackgroundColor(bg); setContentView(root);
        LinearLayout top=new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL); TextView brand=heading("MAP",26); TextView ex=heading("EX",26); ex.setTextColor(blue); top.addView(brand); top.addView(ex); root.addView(top);
        TextView sub=body("NAWIGACJA • ALERTY • BEZPIECZEŃSTWO"); sub.setPadding(0,0,0,18); root.addView(sub);
        ScrollView scroll=new ScrollView(this); content=new LinearLayout(this); content.setOrientation(1); scroll.addView(content); root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout nav=new LinearLayout(this); nav.setGravity(Gravity.CENTER); nav.setPadding(0,10,0,8); root.addView(nav);
        String[] tabs={"Mapa","Pociągi","Alerty","Ustawienia"}; for(String tab:tabs){ Button bt=new Button(this); bt.setText(tab); bt.setTextSize(10); bt.setTextColor(white); bt.setAllCaps(false); bt.setBackgroundTintList(android.content.res.ColorStateList.valueOf(panel)); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-2,1); p.setMargins(3,0,3,0); nav.addView(bt,p); bt.setOnClickListener(v->show(tab)); }
        show("Mapa");
    }
}
